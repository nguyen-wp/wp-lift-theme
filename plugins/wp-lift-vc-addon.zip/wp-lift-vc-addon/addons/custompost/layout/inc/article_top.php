<?php 
$output .= '<article class="lift-ctn'.($add_box_button ? ' lift-hold-click' : '').'">';
$output .= '<div class="lift-box">';