<?php
$icon_position && $icon_position === 'style-1' ? include 'icon.php' : null;
$output .= $title ? $applyHeading : null;
$icon_position && $icon_position === 'style-2' ? include 'icon.php' : null;