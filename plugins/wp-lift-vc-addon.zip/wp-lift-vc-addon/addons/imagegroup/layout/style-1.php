<?php 
include 'inc/heading.php';
include 'inc/img.php';
include 'inc/content.php';
