<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="1,25 12,59 52,59 63,25 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="25" x2="22" y2="5"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="50" y1="25" x2="42" y2="5"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="34" x2="32" y2="52"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="41" y1="43" x2="23" y2="43"/>
</svg>
