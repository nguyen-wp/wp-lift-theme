<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="1" fill="none" stroke="#231F20" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" width="62" height="62"/>
<rect x="1" y="1" fill="none" stroke="#231F20" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" width="62" height="62"/>
<path fill="none" stroke="#231F20" stroke-width="2" stroke-miterlimit="10" d="M22,27c-2.762,0-5-2.238-5-5s2.238-5,5-5
	s5,2.238,5,5v20c0,2.762-2.238,5-5,5s-5-2.238-5-5s2.238-5,5-5h20c2.762,0,5,2.238,5,5s-2.238,5-5,5s-5-2.238-5-5V22
	c0-2.762,2.238-5,5-5s5,2.238,5,5s-2.238,5-5,5H22z"/>
</svg>
