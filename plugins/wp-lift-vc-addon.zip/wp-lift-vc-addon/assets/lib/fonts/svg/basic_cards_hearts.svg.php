<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="44,59 16,45 36,5 63,19 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="31.899,14.004 28,6 1,20 19,59 32,52.964 
	"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="9" x2="37" y2="11"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="7" y1="23" x2="6" y2="21"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="43" y1="53" x2="42" y2="55"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M33,25c-2.848,5.281,3,15,3,15s11.151,0.28,14-5
	c1.18-2.188,1.377-5.718-1-7c-2.188-1.18-5.82-1.188-7,1c1.18-2.188,0.188-4.82-2-6C37.624,21.718,34.181,22.813,33,25z"/>
</svg>
